<?php return array (
  0 => 
  array (
    'id' => 7,
    'slug' => 'branding',
  ),
  1 => 
  array (
    'id' => 17,
    'slug' => 'graphic',
  ),
  2 => 
  array (
    'id' => 4,
    'slug' => 'identity',
  ),
  3 => 
  array (
    'id' => 10,
    'slug' => 'illustration',
  ),
  4 => 
  array (
    'id' => 6,
    'slug' => 'industrial',
  ),
  5 => 
  array (
    'id' => 8,
    'slug' => 'industry',
  ),
  6 => 
  array (
    'id' => 5,
    'slug' => 'logo',
  ),
  7 => 
  array (
    'id' => 9,
    'slug' => 'stationery',
  ),
  8 => 
  array (
    'id' => 11,
    'slug' => 'typography',
  ),
  9 => 
  array (
    'id' => 3,
    'slug' => 'web',
  ),
);